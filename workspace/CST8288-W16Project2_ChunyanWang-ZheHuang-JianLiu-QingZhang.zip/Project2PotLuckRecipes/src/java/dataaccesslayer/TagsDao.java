/* Author: Qing Zhang
 */
package dataaccesslayer;
import java.util.List;

import transferobjects.Tag;

/**
 *
 * @author Jessie
 */
public interface TagsDao {
    List<Tag> getAllTags();
   /** Tag getTagById (Integer tagId);
    void addTag (Tag tag);
    void updateTag(Tag tag);
    void deleteTag(Tag tag);*/
    
    
    
}
