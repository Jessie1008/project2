/* Author: Chunyan Wang
 */
package dataaccesslayer;

import java.util.List;
import transferobjects.Member;

/**
 *
 * @author Jessie
 */
public interface MembersDao {

    public List<Member> getAllMembers();
    
}
